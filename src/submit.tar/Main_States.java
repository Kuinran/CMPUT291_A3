
public enum Main_States {
	LOGIN, MAIN, BOOK, MANAGE_RQ, POST, OFFER, SEARCH, QUIT
}
