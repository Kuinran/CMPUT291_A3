Name - CCID
-----------
Jarrett Yu - jarrett
Michael Huang - chuang4
Nicholas Serrano - nserrano

Collaborators
-------------
We did not collaborate with any other person.

Stack overflow and other similar forums were used for troubleshooting and assistance on general functionalities of Java.

The oracle documents were consulted for the imported packages we used.